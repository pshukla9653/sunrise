<div class="page-header page-header-default">
					<div class="page-header-content">
						<div class="page-title">
							<h4><a href="javascript:window.history.back();"><i class="icon-arrow-left52 position-left"></i></a> <span class="text-semibold">
                            <a href="<?=base_url('dashboard');?>">Dashboard</a></span> - 
                            <a href="<?=base_url($this->uri->segment(2));?>"><?=ucfirst($this->uri->segment(2));?></a></h4>
						</div>

						
					</div>

					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?=base_url('dashboard');?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active"><a href="<?=base_url($this->uri->segment(2));?>"><?=ucfirst($this->uri->segment(2));?></a></li>
						</ul>

						
					</div>
				</div>
				<!-- /page header -->
<!-- Content area -->
				<div class="content">

					<!-- Horizontal form options -->
					<div class="row">
<div class="panel panel-flat">
							<div class="panel-heading">
								<h5 class="panel-title"></h5>
								<div class="heading-elements">
									<ul class="icons-list">
				                		<li><a data-action="collapse"></a></li>
				                		<li><a data-action="reload"></a></li>
				                		<li><a data-action="close"></a></li>
				                	</ul>
			                	</div>
							</div>

							<div class="panel-body">
								<div class="row">
									<?php echo $this->session->flashdata('msg'); ?>
                                    <div class="col-md-12">
										<fieldset>
						                	<legend class="text-semibold"> <?=ucfirst($this->uri->segment(2));?> List</legend>
											<table class="table datatable-basic">
                      <thead>
                      <th>Customer Name</th>
                      <th>Product Name</th>
                      <th>Service Name</th>
                      <th>Mobile</th>
                      <th>Alternate Mobile</th>
                      <th>Land Line NO.</th>
                      <th>Address</th>
                       <th>City</th>
                        <th>PIN Code</th>
                       <th>GSTIN</th>
                      <th>Invoice Status</th>
                       <th>Status</th>
                      <th>Actions</th>
                      
                      </thead>
                                        <tbody>
                                    <?php foreach($customerlist as $item) { ?>
                                    <tr style="text-align:center;">
                                        <td><?php echo $item['customer_name']; ?></td>
                                        <td><?php echo $item['product_name']; ?></td>
                                        <td><?php echo $item['service_name']; ?></td>
                                        <td><?php echo $item['mobile']; ?></td>
                                        <td><?php echo $item['alternate_mobile']; ?></td>
                                        <td><?php echo $item['landline_no']; ?></td>
                                        <td><?php echo $item['address']; ?>, <?php echo $item['city_name']; ?>, <?php echo $item['state_name']; ?>, <?php echo $item['country_name']; ?> - <?php echo $item['zip_code']; ?></td>
                                        <td><?php echo $item['city_name']; ?></td>
                                        <td><?php echo $item['zip_code']; ?></td>
                                        <td><?php echo $item['GSTIN']; ?></td>
                                       <td><?php echo ($item['invoice_status'] == 1) ? '<span class="tag tag-default tag-success">Generated</span>':'<span class="tag tag-default tag-danger">Not Generated</span>'; ?></td>
                                        <td><?php echo ($item['status'] == 1) ? '<span class="tag tag-default tag-success">Active</span>':'<span class="tag tag-default tag-danger">Inactive</span>'; ?></td>
                                        <td>            <a href="<?php echo site_url('secure/customer/generatebill/'.$item['id']); ?>" class="text-info">Generate Invoice</a>
</td>
                                        
                                    </tr>
                                    <?php } ?>
                                </tbody>
                    </table>
										</fieldset>
									</div>
								</div>

								
							</div>
						</div>

</div>

</div>
